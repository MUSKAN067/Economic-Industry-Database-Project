<div class="clearfix"></div>
<footer class="site-footer">
   <div class="footer-inner bg-white">
      <div class="row footer-area">
         <div class="col-sm-6">
            Copyright &copy; 2021 Economic Industries
         </div>
         <div class="col-sm-6 des">
            Designed by <a href="https://www.robotree.co/">robotree.co</a>
         </div>
      </div>
   </div>
</footer>
</div>
<script src="assets/js/vendor/jquery-2.1.4.min.js" type="text/javascript"></script>
<script src="assets/js/popper.min.js" type="text/javascript"></script>
<script src="assets/js/plugins.js" type="text/javascript"></script>
<script src="assets/js/main.js" type="text/javascript"></script>
</body>

</html>

<style>
   .des{
      text-align: end;
   }
   @media (max-width: 768px) {
      .des{
      text-align: center;
   }
      .footer-area {
         display: contents;
         text-align: center;
      }
   }
</style>
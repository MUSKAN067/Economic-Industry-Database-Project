<?php
session_start();
$con=mysqli_connect('localhost','id16902525_economicdb','9/o7tPB%2NG5hA7&','id16902525_economic');
?>
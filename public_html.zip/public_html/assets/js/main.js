$.noConflict();
jQuery(document).ready(function ($) {
  $(window).width(function () {
    var windowWidth = $(window).width();
    if (windowWidth < 760) {
      $(".wrapper").removeClass("active");
      document.getElementById("left-panel").style.display = "none";
    } else {
      document.getElementById("left-panel").style.display = "block";
      $(".wrapper").addClass("active");
    }
  });

  $(window).resize(function () {
    var windowWidth = $(window).width();
    if (windowWidth < 760) {
      $(".wrapper").removeClass("active");
      document.getElementById("left-panel").style.display = "none";
    } else {
      document.getElementById("left-panel").style.display = "block";
      $(".wrapper").addClass("active");
    }
  });

  $("#menuToggle").on("click", function (event) {
    var windowWidth = $(window).width();
    if (windowWidth < 760) {
      $("#left-panel").slideToggle();
    } else {
      $(".wrapper").toggleClass("active");
      $(".right-panel").toggleClass("active");
      $(".top-right").toggleClass("active");
    }
  });

  $(".content").on("click", function (event) {
    var windowWidth = $(window).width();
    if (windowWidth < 760) {
      document.getElementById("left-panel").style.display = "none";
    }
  });

  $(".top-right").on("click", function (event) {
    var windowWidth = $(window).width();
    if (windowWidth < 760) {
      document.getElementById("left-panel").style.display = "none";
    }
  });

  $(".menu-item-has-children.dropdown").each(function () {
    $(this).on("click", function () {
      var $temp_text = $(this).children(".dropdown-toggle").html();
      $(this)
        .children(".sub-menu")
        .prepend('<li class="subtitle">' + $temp_text + "</li>");
    });
  });
});
